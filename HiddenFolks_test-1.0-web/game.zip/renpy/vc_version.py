branch = u'fix'
nightly = False
official = True
version = u'7.6.3.23091805'
version_name = u'To Boldy Go'
